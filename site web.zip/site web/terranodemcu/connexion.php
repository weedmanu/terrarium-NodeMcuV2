<?php

define('DB_HOST' , 'localhost');		// l'adresse de mysql
define('DB_NAME' , 'terranodemcu');		// le nom de la database
define('DB_USER' , 'XXXX'); 			// votre login de la base de donnée
define('DB_PASS' , 'YYYY');		 	    // votre mdp

?>
