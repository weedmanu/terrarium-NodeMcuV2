# Les librairies nécessaires:

Dézippez le dossier, copiez ci qu'il y a dans le dossier **terrarium-NodeMcu_librairie** dans votre dossier librairie.
		
le chemin est généralement :
		
* **/home/xxxx/Arduino/librairies** pour Linux.		
					
ou
		
* **c:/Arduino/librairies** ou **c:/mes document/Arduino/librairies** pour Windows.
